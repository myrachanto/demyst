package product

var sizeSlice []string = []string{"1kg", "2kg", "3kg", "4kg", "5kg"}
